$title Physical reachability of carbon-budget allocations (Brief Communication)
$onText
-------------------------------------------------------------------------------
  BC_reachability.gms   (GAMS 25-compatible)
  Companion model for "No allocation of the remaining carbon budget is
  physically reachable for all regions: a feasibility screen for
  climate-policy proposals."

  The model states equations 1-7 of the Methods and certifies the central
  result as a linear feasibility program:

      a_i^min = E_i * (1 - d_i)^T                    (eq 4)
      budget reachable  <=>  sum_i a_i^min <= B       (eq 6)

  Framed as a deficit-minimising LP:
      min  Deficit
      s.t. sum(i, a(i)) =l= B + Deficit
           a(i)          =g= amin(i)
           a(i), Deficit  >= 0

  D* = max(0, sum_i a_i^min - B)  = irreducible deficit (eq 7).
  D* = 0  =>  budget reachable;  D* > 0  =>  no allocation reachable.

  All data embedded; file is self-contained.
  Verified: sum floors = 11.02 Gt, deficit = 1.02 Gt, reachable = 0.

  FIX LOG (vs first release, for GAMS 25.0.3 compatibility):
    - Variable renamed D -> Deficit  (D reserved as derivative operator)
    - mult(m) grid moved into loop   (ord() in direct assignment needs GAMS 26+)
    - verdict$(...)  rewritten as explicit loop + if-blocks
-------------------------------------------------------------------------------
$offText

* ── 1. Sets ──────────────────────────────────────────────────────────────────
Set  i  'nine macro-regions' /NA, EU, CHN, IND, SSA, MECA, SAS, EAP, LAM/
     p  'published allocation proposals' /EPC, CC, GDR, CER/
     m  'rate-multiplier grid, 1.000 to 1.200 in steps of 0.005' /m1*m41/ ;

* ── 2. Regional baseline ──────────────────────────────────────────────────────
Table base(i,*)
            E       pop        gpc
NA         6.5      0.58      48276
EU         3.6      0.45      42222
CHN       11.0      1.43      11888
IND        2.4      1.44       2569
SSA        1.2      1.20       1750
MECA       2.2      0.50       5600
SAS        3.2      2.00       2100
EAP        4.3      1.80       5278
LAM        1.8      0.65       5231  ;

Parameter E(i), pop(i), g(i);
E(i)   = base(i,'E');
pop(i) = base(i,'pop');
g(i)   = base(i,'gpc');

* ── 3. Constructed allocations (Gt; negative = transfers required) ────────────
Table alloc(i,p)
            EPC       CC      GDR      CER
NA         0.58     0.99    -5.63    -6.32
EU         0.45     0.63    -5.16    -5.43
CHN        1.42     1.98     8.00     8.49
IND        1.43     1.17     1.93     2.03
SSA        1.19     0.90     1.04     1.07
MECA       0.50     0.54     1.96     2.01
SAS        1.99     1.61     2.83     2.90
EAP        1.79     1.58     3.70     3.82
LAM        0.65     0.60     1.33     1.43  ;

* ── 4. Scalars ────────────────────────────────────────────────────────────────
$if not set BUD $set BUD 10
$if not set HOR $set HOR 50
Scalar B 'carbon budget (Gt)'  / %BUD% /
       T 'horizon (years)'      / %HOR% / ;

* ── 5. Capacity tiers and decline frontier (Methods eq 5) ────────────────────
Scalar gbar 'population-weighted mean per-capita income';
gbar = sum(i, pop(i)*g(i)) / sum(i, pop(i));

Parameter d(i) 'maximum sustained annual decline rate';
d(i) = 0;
d(i)$(g(i) <  0.3*gbar)                       = 0.015;
d(i)$(g(i) >= 0.3*gbar and g(i) < 0.7*gbar)  = 0.020;
d(i)$(g(i) >= 0.7*gbar and g(i) < 1.5*gbar)  = 0.025;
d(i)$(g(i) >= 1.5*gbar)                       = 0.035;

* ── 6. Feasibility floor (eq 4): a_i^min = E_i * (1 - d_i)^T ────────────────
Parameter amin(i) 'feasibility floor (Gt)';
amin(i) = E(i) * power(1 - d(i), T);

* ── 7. Deficit-minimising feasibility LP (eq 6-7) ────────────────────────────
*    NOTE: variable renamed Deficit (not D) to avoid clash with GAMS derivative
*    operator in GAMS 25.
Positive Variables a(i)    'regional allowance (Gt)'
                   Deficit  'irreducible budget overshoot (Gt)';
Free Variable      z        'objective';

Equations obj, budget, floorcon(i);
obj..         z =e= Deficit;
budget..      sum(i, a(i)) =l= B + Deficit;
floorcon(i).. a(i) =g= amin(i);

Model reach 'reachability feasibility program' / obj, budget, floorcon /;
solve reach using lp minimizing z;

* ── 8. Report ────────────────────────────────────────────────────────────────
Scalar sumfloor, def_val, reachable;
sumfloor = sum(i, amin(i));
def_val  = Deficit.l;
reachable = 0;
if(Deficit.l <= 1e-9, reachable = 1);

display gbar, d, amin, sumfloor, B, T, def_val, reachable;

* Per-proposal reachability (reproduces Fig 1c):
*   1 = clears floor,  0 = below floor (unreachable),  -1 = net-negative
Parameter verdict(i,p)  'reachability verdict per region per proposal'
          n_clear(p)    'number of regions clearing the floor';
verdict(i,p) = 0;
loop((i,p),
    if(alloc(i,p) < 0,           verdict(i,p) = -1; );
    if(alloc(i,p) >= amin(i),    verdict(i,p) =  1; );
);
n_clear(p) = sum(i, 1$(verdict(i,p) eq 1));
display verdict, n_clear;

* ── 9. Sensitivity: rate-multiplier boundary and conservative bound ───────────
Parameter mult(m)  'rate multiplier'
          sf(m)    'summed floors at each multiplier';

* Build the multiplier grid with a loop (ord() in direct assignment needs v26+)
loop(m,
    mult(m) = 1.00 + 0.005*(ord(m)-1);
    sf(m)   = sum(i, E(i) * power(1 - mult(m)*d(i), T));
);
display sf;
* crosses B (~10 Gt) near mult = 1.085

* Conservative bound: recalibrate top tier to the observed frontier (2.15 %/yr)
Parameter d_obs(i)    'observed-calibrated decline rate'
          amin_obs(i) 'floor under observed calibration';
Scalar    sf_obs      'summed floors under observed calibration'
          def_obs     'deficit under observed calibration';

d_obs(i)   = d(i);
d_obs(i)$(d(i) = 0.035) = 0.0215;
amin_obs(i) = E(i) * power(1 - d_obs(i), T);
sf_obs      = sum(i, amin_obs(i));
def_obs     = sf_obs - B;
display d_obs, amin_obs, sf_obs, def_obs;

* ── 10. GDX output ───────────────────────────────────────────────────────────
execute_unload 'bc_results.gdx',
   i, p, m, E, pop, g, gbar, d, amin, a, Deficit, sumfloor, def_val, reachable,
   verdict, n_clear, mult, sf, d_obs, amin_obs, sf_obs, def_obs;
