import pandas as pd, numpy as np, json
import os
DATA=os.environ.get('BC_DATA', os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','data'))
rng=np.random.default_rng(11)

EM=pd.read_csv(os.path.join(DATA,'backtest','emissions_by_country_year.csv'))
MAP=pd.read_csv(os.path.join(DATA,'backtest','region_mapping.csv'),keep_default_na=False).set_index('country')['region'].to_dict()
BASE=pd.read_csv(os.path.join(DATA,'data_baseline_regions.csv'),keep_default_na=False)
BASE['emissions_Gt']=BASE['emissions_Gt'].astype(float)

# ---- model tier caps (BC) keyed by region ----
CAP={'NA':0.035,'EU':0.035,'CHN':0.025,'IND':0.015,'SSA':0.015,'MECA':0.020,'SAS':0.015,'EAP':0.020,'LAM':0.020}
EMIS={r.region:r.emissions_Gt for r in BASE.itertuples()}
B=10.0; T=50
REG=list(EMIS)

# ---- World Bank income group (standard public classification) ----
INCGROUP={'USA':'High','CAN':'High','DEU':'High','FRA':'High','GBR':'High','JPN':'High','SAU':'High',
          'CHN':'Upper-middle','BRA':'Upper-middle','ZAF':'Upper-middle','MEX':'Upper-middle',
          'IND':'Lower-middle','IDN':'Lower-middle','NGA':'Lower-middle','PAK':'Lower-middle'}

# ---- per-country observed decline rates ----
rows=[]
for c in EM.country.unique():
    s=EM[EM.country==c].sort_values('year'); yr=s.year.values.astype(float); em=s.emissions.values.astype(float)
    pk=int(np.argmax(em)); peak_yr,peak_v=yr[pk],em[pk]; last_yr,last_v=yr[-1],em[-1]
    postpeak=(-( (last_v/peak_v)**(1/(last_yr-peak_yr))-1 )*100) if (last_yr>peak_yr and last_v<peak_v) else 0.0
    best=0.0; bw=None
    for i in range(len(yr)):
        for j in range(i+1,len(yr)):
            if yr[j]-yr[i]>=10:
                r=(em[j]/em[i])**(1/(yr[j]-yr[i]))-1
                if r<best: best=r; bw=(int(yr[i]),int(yr[j]))
    rows.append({'country':c,'region':MAP[c],'income':INCGROUP[c],'peak_yr':int(peak_yr),
                 'postpeak_%/yr':round(postpeak,2),'decadal_max_%/yr':round(-best*100,2) if best<0 else 0.0,
                 'decadal_window':f"{bw[0]}-{bw[1]}" if bw else "—",'cap_%/yr':CAP[MAP[c]]*100})
T5=pd.DataFrame(rows).sort_values('postpeak_%/yr',ascending=False)
pd.set_option('display.width',170)
print("=== OBSERVED SUSTAINED DECLINE RATES (real 15-country panel, 1990-2023) ===")
print(T5.to_string(index=False))
T5.to_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','results','S5_observed_rates.csv'),index=False)

declined=T5[T5['postpeak_%/yr']>0]
print(f"\nCountries with sustained post-peak decline: {len(declined)} of 15")
print(f"Fastest multi-decade sustained decline: {declined['postpeak_%/yr'].max():.2f}%/yr "
      f"({declined.loc[declined['postpeak_%/yr'].idxmax(),'country']})")
print(f"Fastest single-decade rate (any window): {T5['decadal_max_%/yr'].max():.2f}%/yr "
      f"({T5.loc[T5['decadal_max_%/yr'].idxmax(),'country']})")

# high-capacity group observed (post-peak) -> empirical dispersion for the binding frontier
hi=T5[(T5.income=='High')&(T5['postpeak_%/yr']>0)]['postpeak_%/yr'].values
print(f"\nHigh-income observed post-peak rates: {sorted(hi,reverse=True)}")
print(f"  mean={hi.mean():.2f}  sd={hi.std(ddof=1):.2f}  CV={hi.std(ddof=1)/hi.mean():.3f}")

# ---- floors ----
def floors(capvec): return np.array([EMIS[r]*(1-capvec[r])**T for r in REG])
amin=floors(CAP); print(f"\nModel-frontier  Sum floors={amin.sum():.2f} Gt  deficit={amin.sum()-B:.2f} Gt")

# ---- CONSERVATIVE BOUND: recalibrate binding top tier to the observed sustained max ----
obs_top=hi.max()/100   # 2.15%/yr  (UK, observed multi-decade max for the high-capacity frontier)
CAP_obs=dict(CAP); CAP_obs['NA']=obs_top; CAP_obs['EU']=obs_top
amin_obs=floors(CAP_obs)
print(f"Observed-calibrated top tier ({obs_top*100:.2f}%/yr for NA,EU): "
      f"Sum floors={amin_obs.sum():.2f} Gt  deficit={amin_obs.sum()-B:.2f} Gt")
print("  -> lowering the cap to the observed frontier DEEPENS the deficit (caps are generous).")

# ---- S6: uncertainty grounded DIRECTLY in observed data (nonparametric bootstrap) ----
# multiplicative factors = observed high-capacity rates / their mean (empirical shape of dispersion)
fac=hi/hi.mean()
N=200000
draws=rng.choice(fac,size=(N,len(REG)),replace=True)
caps_bs=np.clip(np.array([CAP[r] for r in REG])[None,:]*draws,0.003,0.07)
Es=np.array([EMIS[r] for r in REG])[None,:]
sf_bs=(Es*(1-caps_bs)**T).sum(1)
p_bs=(sf_bs>B).mean()
print(f"\n=== S6 BOOTSTRAP (factors resampled from observed high-capacity dispersion) ===")
print(f"  P(infeasible)={p_bs:.3f}  mean={sf_bs.mean():.2f}  5-95%=[{np.percentile(sf_bs,5):.2f},{np.percentile(sf_bs,95):.2f}]")

# robustness across parametric CV anchored on the observed CV
cvobs=hi.std(ddof=1)/hi.mean()
cvs=np.linspace(0.05,0.45,17); P=[]
for cv in cvs:
    cdraw=np.clip(np.array([CAP[r] for r in REG])[None,:]*(1+cv*rng.standard_normal((120000,len(REG)))),0.003,0.07)
    P.append(((Es*(1-cdraw)**T).sum(1)>B).mean())
P=np.array(P)
print(f"  observed CV={cvobs:.3f} -> parametric P(infeasible)~{P[np.argmin(abs(cvs-cvobs))]:.3f}")
print(f"  P range over CV[0.05,0.45]: {P.max():.3f} .. {P.min():.3f}")

json.dump({'fastest_multidecade':round(float(declined['postpeak_%/yr'].max()),2),
           'fastest_decadal':round(float(T5['decadal_max_%/yr'].max()),2),
           'hi_mean':round(float(hi.mean()),2),'hi_cv':round(float(cvobs),3),
           'sum_model':round(float(amin.sum()),2),'def_model':round(float(amin.sum()-B),2),
           'sum_obs':round(float(amin_obs.sum()),2),'def_obs':round(float(amin_obs.sum()-B),2),
           'obs_top_pct':round(float(obs_top*100),2),
           'p_bootstrap':round(float(p_bs),2),'p_min':round(float(P.min()),2),'p_max':round(float(P.max()),2)},
          open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','results','S5S6_numbers.json'),'w'),indent=1)
print("\nnumbers -> /tmp/S5S6_numbers.json")
